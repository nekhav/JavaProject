package javaProject;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Login {

	public static void main(String args[]) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cupcake\\Desktop\\Project1\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.guru99.com/test/newtours/login.php");
		
		driver.findElement(By.name("userName")).sendKeys("Nekha@gmail.com");
		driver.findElement(By.name("password")).sendKeys("Nekha@123");
		driver.findElement(By.name("submit")).click();
		
		String actualUrl="http://demo.guru99.com/test/newtours/login_sucess.php";
		String expectedUrl = driver.getCurrentUrl();
		
	if(actualUrl.equalsIgnoreCase(expectedUrl))
	{

		System.out.println("Test Passed");
	}
	else
	{
		System.out.println("Test Failed");
	}
		
		
	}
	driver.close();
}
