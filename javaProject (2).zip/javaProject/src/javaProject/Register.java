package javaProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Register {

	public static void main(String args[]) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cupcake\\Desktop\\Project1\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	
		driver.get("http://demo.guru99.com/test/newtours/register.php");
		
			
		driver.findElement(By.name("firstName")).sendKeys("John");
		driver.findElement(By.name("lastName")).sendKeys("Nekha");
		driver.findElement(By.name("phone")).sendKeys("0728866150");
		driver.findElement(By.name("userName")).sendKeys("Nekha@gmail.com");
		driver.findElement(By.name("address1")).sendKeys("8211 molete street Attteridgeville");
		driver.findElement(By.name("city")).sendKeys("Pretoria");
		driver.findElement(By.name("state")).sendKeys("Gauteng");
		
		Select country = new Select(driver.findElement(By.name("country")));
		country.selectByVisibleText("SOUTH AFRICA");
		
		driver.findElement(By.name("postalCode")).sendKeys("0008");
		driver.findElement(By.id("email")).sendKeys("Nekha@gmail.com");
		driver.findElement(By.name("password")).sendKeys("Nekha@123");
		driver.findElement(By.name("confirmPassword")).sendKeys("Nekha@123");
		
		
		
		driver.findElement(By.name("submit")).click();		
		
		String actualUrl="http://demo.guru99.com/test/newtours/register_sucess.php";
		String expectedUrl = driver.getCurrentUrl();

		if( actualUrl.equalsIgnoreCase(expectedUrl))
		{
			System.out.println("Test Passed.");
		}
		else
		{
			System.out.println("Test Failed.");
		}
		
		
	}
	driver.close();

}
